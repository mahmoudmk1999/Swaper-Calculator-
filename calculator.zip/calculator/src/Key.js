import { useEffect, useRef } from 'react';
import { Animated, Easing, Pressable, StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';

// Colors for each key role, taken from the Material 3 scheme.
function palette(theme, variant, active) {
  if (active) return [theme.primary, theme.onPrimary];
  switch (variant) {
    case 'op':
      return [theme.secondaryContainer, theme.onSecondaryContainer];
    case 'clear':
      return [theme.tertiaryContainer, theme.onTertiaryContainer];
    case 'eq':
      return [theme.primary, theme.onPrimary];
    case 'sci':
      return ['transparent', theme.onSurfaceVariant];
    default:
      return [theme.surfaceContainerHigh, theme.onSurface];
  }
}

/**
 * A Material "expressive" button: round at rest, morphs toward a rounded
 * square while pressed, with a native ripple and a soft scale.
 */
export default function Key({
  label,
  icon,
  value,
  variant = 'num',
  w,
  h,
  theme,
  index = 0,
  active = false,
  onPress,
  onLongPress,
  fontSize,
}) {
  const scale = useRef(new Animated.Value(1)).current; // native driver
  const morph = useRef(new Animated.Value(0)).current; // JS driver (borderRadius)
  const enter = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(enter, {
      toValue: 1,
      duration: 420,
      delay: 60 + index * 22,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  }, []);

  const pressIn = () => {
    Haptics.impactAsync(
      variant === 'eq' ? Haptics.ImpactFeedbackStyle.Medium : Haptics.ImpactFeedbackStyle.Light
    ).catch(() => {});
    Animated.spring(scale, { toValue: 0.94, friction: 7, tension: 260, useNativeDriver: true }).start();
    Animated.spring(morph, { toValue: 1, friction: 8, tension: 220, useNativeDriver: false }).start();
  };
  const pressOut = () => {
    Animated.spring(scale, { toValue: 1, friction: 5, tension: 160, useNativeDriver: true }).start();
    Animated.spring(morph, { toValue: 0, friction: 6, tension: 120, useNativeDriver: false }).start();
  };

  const [bg, fg] = palette(theme, variant, active);
  const round = Math.min(w, h) / 2;
  const radius = morph.interpolate({ inputRange: [0, 1], outputRange: [round, Math.min(w, h) * 0.26] });
  const size = fontSize ?? (variant === 'sci' ? h * 0.4 : h * 0.4);

  return (
    <Animated.View
      style={{
        opacity: enter,
        transform: [
          { translateY: enter.interpolate({ inputRange: [0, 1], outputRange: [18, 0] }) },
          { scale },
        ],
      }}
    >
      <Animated.View style={{ width: w, height: h, borderRadius: radius, backgroundColor: bg, overflow: 'hidden' }}>
        <Pressable
          onPressIn={pressIn}
          onPressOut={pressOut}
          onPress={() => onPress(value ?? label)}
          onLongPress={onLongPress}
          android_ripple={{ color: theme.dark ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0.08)' }}
          style={styles.fill}
        >
          <View style={styles.center}>
            {icon ? (
              <MaterialIcons name={icon} size={h * 0.36} color={fg} />
            ) : (
              <Text
                allowFontScaling={false}
                style={{ color: fg, fontSize: size, fontWeight: variant === 'sci' ? '500' : '400' }}
              >
                {label}
              </Text>
            )}
          </View>
        </Pressable>
      </Animated.View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
});
