// Calculator engine: input handling + a small recursive-descent parser.
// No eval(). Pure functions, so it can be tested outside React Native.

export const BINARY = ['+', '−', '×', '÷', '^'];
export const POSTFIX = ['!', '%', '²', '⁻¹'];
export const CONSTS = ['π', 'e'];
export const FUNCS = ['sin(', 'cos(', 'tan(', 'ln(', 'log(', 'sin⁻¹(', 'cos⁻¹(', 'tan⁻¹('];

const MAX_DIGITS = 15;
const MAX_TOKENS = 120;

const isDigit = (t) => /^[0-9.]$/.test(t);
const isNumberToken = (t) => /^[0-9.]+(e[+-]?\d+)?$/.test(t);
const opens = (t) => t === '(' || FUNCS.includes(t);
// tokens after which a value is "complete" (a ')' or postfix can follow)
const endsValue = (t) => t !== undefined && (isNumberToken(t) || CONSTS.includes(t) || t === ')' || POSTFIX.includes(t));

/* ---------------- numbers ---------------- */

export function clean(n) {
  if (!isFinite(n)) return n;
  const r = parseFloat(n.toPrecision(12));
  return Object.is(r, -0) ? 0 : r;
}

export function numToStr(n) {
  n = clean(n);
  const a = Math.abs(n);
  if (a !== 0 && (a >= 1e15 || a < 1e-9)) {
    return n.toExponential(8).replace(/\.?0+e/, 'e');
  }
  return String(n);
}

function group(numStr) {
  if (numStr.includes('e')) return numStr;
  const [int, dec] = numStr.split('.');
  const g = int.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return dec !== undefined ? g + '.' + dec : g;
}

export function formatNumber(n) {
  const s = numToStr(n);
  return s.startsWith('-') ? '−' + group(s.slice(1)) : group(s);
}

export function numberToTokens(n) {
  const s = numToStr(n);
  const neg = s.startsWith('-');
  const body = neg ? s.slice(1) : s;
  const parts = body.includes('e') ? [body] : body.split('');
  return neg ? ['−', ...parts] : parts;
}

/* ---------------- lexing / display ---------------- */

function lex(tokens) {
  const out = [];
  for (const t of tokens) {
    const last = out[out.length - 1];
    if (isDigit(t) && last && last.t === 'num' && !last.raw.includes('e')) {
      last.raw += t;
    } else if (isDigit(t) || isNumberToken(t)) {
      out.push({ t: 'num', raw: t });
    } else if (BINARY.includes(t)) out.push({ t: 'op', v: t });
    else if (POSTFIX.includes(t)) out.push({ t: 'post', v: t });
    else if (CONSTS.includes(t)) out.push({ t: 'const', v: t });
    else if (FUNCS.includes(t)) out.push({ t: 'func', v: t });
    else if (t === '√') out.push({ t: 'sqrt' });
    else if (t === '(') out.push({ t: 'lp' });
    else if (t === ')') out.push({ t: 'rp' });
  }
  return out;
}

export function formatExpr(tokens) {
  return lex(tokens)
    .map((u) => {
      if (u.t === 'num') return group(u.raw);
      if (u.t === 'op') return u.v;
      if (u.t === 'post' || u.t === 'const' || u.t === 'func') return u.v;
      if (u.t === 'sqrt') return '√';
      return u.t === 'lp' ? '(' : ')';
    })
    .join('');
}

/* ---------------- parser ---------------- */

class CalcError extends Error {
  constructor(kind) {
    super(kind);
    this.kind = kind; // 'incomplete' | 'div0' | 'domain' | 'overflow'
  }
}

function factorial(n) {
  if (n < 0 || !Number.isInteger(n)) throw new CalcError('domain');
  if (n > 170) throw new CalcError('overflow');
  let r = 1;
  for (let i = 2; i <= n; i++) r *= i;
  return r;
}

function evaluateUnits(units, deg) {
  let i = 0;
  const peek = () => units[i];
  const startsPrimary = (u) => u && ['num', 'const', 'func', 'sqrt', 'lp'].includes(u.t);
  const toRad = (x) => (deg ? (x * Math.PI) / 180 : x);
  const fromRad = (x) => (deg ? (x * 180) / Math.PI : x);
  const snap = (x) => (Math.abs(x) < 1e-12 ? 0 : x);

  function closeParen() {
    if (peek() && peek().t === 'rp') i++;
    else if (peek()) throw new CalcError('incomplete');
    // end of input: parenthesis auto-closes
  }

  function primary() {
    const u = units[i++];
    if (!u) throw new CalcError('incomplete');
    switch (u.t) {
      case 'num': {
        const v = parseFloat(u.raw === '.' ? '0' : u.raw);
        if (isNaN(v)) throw new CalcError('incomplete');
        return v;
      }
      case 'const':
        return u.v === 'π' ? Math.PI : Math.E;
      case 'lp': {
        const v = expr();
        closeParen();
        return v;
      }
      case 'sqrt': {
        const v = power();
        if (v < 0) throw new CalcError('domain');
        return Math.sqrt(v);
      }
      case 'func': {
        const x = expr();
        closeParen();
        switch (u.v) {
          case 'sin(':
            return snap(Math.sin(toRad(x)));
          case 'cos(':
            return snap(Math.cos(toRad(x)));
          case 'tan(': {
            if (Math.abs(Math.cos(toRad(x))) < 1e-12) throw new CalcError('domain');
            return snap(Math.tan(toRad(x)));
          }
          case 'sin⁻¹(':
          case 'cos⁻¹(': {
            if (x < -1 || x > 1) throw new CalcError('domain');
            return fromRad(u.v === 'sin⁻¹(' ? Math.asin(x) : Math.acos(x));
          }
          case 'tan⁻¹(':
            return fromRad(Math.atan(x));
          case 'ln(':
            if (x <= 0) throw new CalcError('domain');
            return Math.log(x);
          case 'log(':
            if (x <= 0) throw new CalcError('domain');
            return Math.log10(x);
        }
      }
    }
    throw new CalcError('incomplete');
  }

  function postfix() {
    let v = primary();
    while (peek() && peek().t === 'post') {
      const p = units[i++].v;
      if (p === '!') v = factorial(v);
      else if (p === '%') v = v / 100;
      else if (p === '²') v = v * v;
      else if (p === '⁻¹') {
        if (v === 0) throw new CalcError('div0');
        v = 1 / v;
      }
    }
    return v;
  }

  function power() {
    const b = postfix();
    if (peek() && peek().t === 'op' && peek().v === '^') {
      i++;
      const e = unary();
      const r = Math.pow(b, e);
      if (isNaN(r)) throw new CalcError('domain');
      return r;
    }
    return b;
  }

  function unary() {
    const u = peek();
    if (u && u.t === 'op' && u.v === '−') {
      i++;
      return -unary();
    }
    if (u && u.t === 'op' && u.v === '+') {
      i++;
      return unary();
    }
    return power();
  }

  function term() {
    let v = unary();
    for (;;) {
      const u = peek();
      if (u && u.t === 'op' && (u.v === '×' || u.v === '÷')) {
        i++;
        const r = unary();
        if (u.v === '÷') {
          if (r === 0) throw new CalcError('div0');
          v = v / r;
        } else v = v * r;
      } else if (startsPrimary(u)) {
        v = v * unary(); // implicit multiplication: 2π, 3(4), 2sin(30)
      } else return v;
    }
  }

  function expr() {
    let v = term();
    for (;;) {
      const u = peek();
      if (u && u.t === 'op' && (u.v === '+' || u.v === '−')) {
        i++;
        const r = term();
        v = u.v === '+' ? v + r : v - r;
      } else return v;
    }
  }

  const v = expr();
  if (i < units.length) throw new CalcError('incomplete');
  if (!isFinite(v)) throw new CalcError('overflow');
  return clean(v);
}

export function evaluate(tokens, deg = true) {
  if (!tokens.length) throw new CalcError('incomplete');
  return evaluateUnits(lex(tokens), deg);
}

export const ERROR_TEXT = {
  incomplete: 'تعبير غير مكتمل',
  div0: 'لا يمكن القسمة على صفر',
  domain: 'خارج نطاق الدالة',
  overflow: 'الرقم كبير جداً',
};

/** Preview of the running answer, or '' when there's nothing useful to show. */
export function preview(tokens, deg) {
  if (!tokens.length) return '';
  const units = lex(tokens);
  if (units.length === 1 && units[0].t === 'num') return '';
  try {
    return formatNumber(evaluate(tokens, deg));
  } catch {
    return '';
  }
}

/* ---------------- input ---------------- */

export const initialState = { tokens: [], justEvaluated: false, lastExpr: null, error: null };

function currentNumber(tokens) {
  let s = '';
  for (let k = tokens.length - 1; k >= 0 && isDigit(tokens[k]); k--) s = tokens[k] + s;
  return s;
}

function openCount(tokens) {
  let n = 0;
  for (const t of tokens) {
    if (opens(t)) n++;
    else if (t === ')') n--;
  }
  return n;
}

/**
 * Apply a key press. Returns { state, event, entry }.
 * event: 'type' | 'result' | 'error' | 'none'
 */
export function press(state, key, deg = true) {
  let { tokens, justEvaluated } = state;
  const base = { ...state, error: null };
  const last = tokens[tokens.length - 1];
  const fresh = (t) => ({ state: { ...base, tokens: t, justEvaluated: false, lastExpr: null }, event: 'type' });
  const put = (t) => {
    if (t.length > MAX_TOKENS) return { state, event: 'error' };
    return { state: { ...base, tokens: t, justEvaluated: false, lastExpr: justEvaluated ? null : state.lastExpr }, event: 'type' };
  };

  // digits
  if (/^[0-9]$/.test(key)) {
    if (justEvaluated) return fresh([key]);
    const cur = currentNumber(tokens);
    if (cur.replace('.', '').length >= MAX_DIGITS) return { state, event: 'error' };
    if (cur === '0') return put([...tokens.slice(0, -1), key]);
    return put([...tokens, key]);
  }

  if (key === '.') {
    if (justEvaluated) return fresh(['0', '.']);
    const cur = currentNumber(tokens);
    if (cur.includes('.')) return { state, event: 'none' };
    if (isNumberToken(last || '') && !isDigit(last)) return { state, event: 'none' };
    return put(cur ? [...tokens, '.'] : [...tokens, '0', '.']);
  }

  if (key === 'AC') return { state: { ...initialState }, event: 'type' };

  if (key === '⌫') {
    if (justEvaluated) {
      const t = tokens.length === 1 && tokens[0].length > 1 ? [] : tokens.slice(0, -1);
      return put(t);
    }
    if (!tokens.length) return { state, event: 'none' };
    return put(tokens.slice(0, -1));
  }

  // binary operators
  if (BINARY.includes(key)) {
    if (justEvaluated) return put([...tokens, key]);
    if (key === '−') {
      if (last === '+' || last === '−') return put([...tokens.slice(0, -1), '−']);
      return put([...tokens, '−']); // unary minus is fine everywhere else
    }
    if (!tokens.length || opens(last) || last === '√') return { state, event: 'none' };
    if (BINARY.includes(last)) {
      // replace operator(s), including a trailing unary minus like "×−"
      let t = tokens.slice(0, -1);
      if (last === '−' && BINARY.includes(t[t.length - 1])) t = t.slice(0, -1);
      if (!t.length) return { state, event: 'none' };
      return put([...t, key]);
    }
    return put([...tokens, key]);
  }

  if (POSTFIX.includes(key)) {
    if (!endsValue(last)) return { state, event: 'none' };
    return put([...tokens, key]);
  }

  if (CONSTS.includes(key) || FUNCS.includes(key) || key === '√') {
    if (justEvaluated) return fresh([key]);
    return put([...tokens, key]);
  }

  if (key === 'eˣ' || key === '10ˣ') {
    const seq = key === 'eˣ' ? ['e', '^', '('] : ['1', '0', '^', '('];
    if (justEvaluated) return fresh(seq);
    const t = key === '10ˣ' && endsValue(last) ? [...tokens, '×'] : tokens;
    return put([...t, ...seq]);
  }

  if (key === '()') {
    if (justEvaluated) return put([...tokens, '×', '(']);
    if (openCount(tokens) > 0 && endsValue(last)) return put([...tokens, ')']);
    return put([...tokens, '(']);
  }

  if (key === '=') {
    if (!tokens.length || justEvaluated) return { state, event: 'none' };
    let t = [...tokens];
    for (let n = openCount(t); n > 0; n--) t.push(')');
    try {
      const value = evaluate(t, deg);
      return {
        state: { tokens: numberToTokens(value), justEvaluated: true, lastExpr: t, error: null },
        event: 'result',
        entry: { expr: formatExpr(t), result: formatNumber(value), value, tokens: t, at: Date.now() },
      };
    } catch (e) {
      return { state: { ...state, error: ERROR_TEXT[e.kind] || ERROR_TEXT.incomplete }, event: 'error' };
    }
  }

  return { state, event: 'none' };
}

/** Insert a number (e.g. from history) into the current input. */
export function insertValue(state, value) {
  const nt = numberToTokens(value);
  const last = state.tokens[state.tokens.length - 1];
  if (state.justEvaluated || !state.tokens.length) {
    return { ...initialState, tokens: nt };
  }
  if (endsValue(last)) return { ...state, tokens: [...state.tokens, '×', ...nt], error: null };
  return { ...state, tokens: [...state.tokens, ...nt], error: null };
}
