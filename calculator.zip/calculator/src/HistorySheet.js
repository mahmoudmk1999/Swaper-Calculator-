import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert,
  Animated,
  BackHandler,
  Easing,
  Pressable,
  SectionList,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

function dayLabel(ts) {
  const d = new Date(ts);
  const today = new Date();
  const start = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = Math.round((start(today) - start(d)) / 86400000);
  if (diff === 0) return 'اليوم';
  if (diff === 1) return 'أمس';
  return `${d.getDate()}/${d.getMonth() + 1}/${d.getFullYear()}`;
}

function timeLabel(ts) {
  const d = new Date(ts);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

/** History drawer that slides down from the top, like the stock Android calculator. */
export default function HistorySheet({ open, onClose, history, onPick, onEdit, onClear, theme, topInset }) {
  const { height } = useWindowDimensions();
  const sheetH = Math.round(height * 0.78);
  const anim = useRef(new Animated.Value(0)).current;
  const [mounted, setMounted] = useState(open);

  useEffect(() => {
    if (open) setMounted(true);
    Animated.timing(anim, {
      toValue: open ? 1 : 0,
      duration: open ? 380 : 260,
      easing: open ? Easing.out(Easing.exp) : Easing.in(Easing.cubic),
      useNativeDriver: true,
    }).start(({ finished }) => finished && !open && setMounted(false));
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      onClose();
      return true;
    });
    return () => sub.remove();
  }, [open]);

  const sections = useMemo(() => {
    const map = new Map();
    for (const e of history) {
      const k = dayLabel(e.at);
      if (!map.has(k)) map.set(k, []);
      map.get(k).push(e);
    }
    return [...map.entries()].map(([title, data]) => ({ title, data }));
  }, [history]);

  if (!mounted) return null;

  const confirmClear = () =>
    Alert.alert('مسح السجل؟', 'سيتم حذف كل العمليات المحفوظة.', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'مسح', style: 'destructive', onPress: onClear },
    ]);

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="box-none">
      <Animated.View style={[StyleSheet.absoluteFill, { backgroundColor: theme.scrim, opacity: anim }]}>
        <Pressable style={{ flex: 1 }} onPress={onClose} />
      </Animated.View>

      <Animated.View
        style={[
          styles.sheet,
          {
            height: sheetH + topInset,
            paddingTop: topInset,
            backgroundColor: theme.surfaceContainer,
            transform: [{ translateY: anim.interpolate({ inputRange: [0, 1], outputRange: [-(sheetH + topInset), 0] }) }],
          },
        ]}
      >
        <View style={styles.header}>
          <Pressable onPress={onClose} hitSlop={10} android_ripple={{ color: theme.outlineVariant, borderless: true, radius: 22 }} style={styles.iconBtn}>
            <MaterialIcons name="close" size={24} color={theme.onSurfaceVariant} />
          </Pressable>
          <Text style={[styles.title, { color: theme.onSurface }]}>السجل</Text>
          <Pressable
            onPress={confirmClear}
            disabled={!history.length}
            hitSlop={10}
            android_ripple={{ color: theme.outlineVariant, borderless: true, radius: 22 }}
            style={[styles.iconBtn, { opacity: history.length ? 1 : 0.35 }]}
          >
            <MaterialIcons name="delete-sweep" size={24} color={theme.onSurfaceVariant} />
          </Pressable>
        </View>

        {history.length === 0 ? (
          <View style={styles.empty}>
            <MaterialIcons name="history" size={56} color={theme.outlineVariant} />
            <Text style={[styles.emptyText, { color: theme.onSurfaceVariant }]}>لا توجد عمليات بعد</Text>
          </View>
        ) : (
          <SectionList
            sections={sections}
            keyExtractor={(item) => String(item.at)}
            contentContainerStyle={{ paddingBottom: 24 }}
            stickySectionHeadersEnabled={false}
            renderSectionHeader={({ section }) => (
              <Text style={[styles.section, { color: theme.primary }]}>{section.title}</Text>
            )}
            renderItem={({ item }) => (
              <Pressable
                onPress={() => onPick(item)}
                onLongPress={() => onEdit(item)}
                android_ripple={{ color: theme.outlineVariant }}
                style={styles.item}
              >
                <View style={styles.itemTop}>
                  <Text style={[styles.time, { color: theme.outline }]}>{timeLabel(item.at)}</Text>
                  <Text style={[styles.expr, { color: theme.onSurfaceVariant }]} numberOfLines={2}>
                    {item.expr}
                  </Text>
                </View>
                <Text style={[styles.result, { color: theme.onSurface }]} numberOfLines={1} adjustsFontSizeToFit>
                  = {item.result}
                </Text>
              </Pressable>
            )}
            ItemSeparatorComponent={() => <View style={[styles.sep, { backgroundColor: theme.outlineVariant }]} />}
          />
        )}

        <Text style={[styles.hint, { color: theme.outline }]}>اضغط لاستخدام النتيجة • اضغط مطولاً لتعديل العملية</Text>
        <View style={[styles.handle, { backgroundColor: theme.outline }]} />
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  sheet: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    borderBottomLeftRadius: 28,
    borderBottomRightRadius: 28,
    overflow: 'hidden',
    elevation: 6,
  },
  header: { height: 64, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 12 },
  iconBtn: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center' },
  title: { fontSize: 22, fontWeight: '500' },
  section: { fontSize: 14, fontWeight: '600', textAlign: 'right', writingDirection: 'rtl', paddingHorizontal: 24, paddingTop: 18, paddingBottom: 6 },
  item: { paddingHorizontal: 24, paddingVertical: 12 },
  itemTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  time: { fontSize: 12 },
  expr: { flex: 1, fontSize: 17, textAlign: 'right' },
  result: { fontSize: 28, textAlign: 'right', marginTop: 2, fontWeight: '400' },
  sep: { height: StyleSheet.hairlineWidth, marginHorizontal: 24 },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  emptyText: { fontSize: 16 },
  hint: { fontSize: 12, textAlign: 'center', paddingVertical: 8, writingDirection: 'rtl' },
  handle: { width: 32, height: 4, borderRadius: 2, alignSelf: 'center', marginBottom: 10, opacity: 0.5 },
});
