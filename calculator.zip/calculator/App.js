import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Animated,
  Easing,
  I18nManager,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  ToastAndroid,
  View,
  useColorScheme,
  useWindowDimensions,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Clipboard from 'expo-clipboard';
import * as Haptics from 'expo-haptics';
import { MaterialIcons } from '@expo/vector-icons';
import { useFonts, GreatVibes_400Regular } from '@expo-google-fonts/great-vibes';

import Key from './src/Key';
import HistorySheet from './src/HistorySheet';
import { light, dark } from './src/theme';
import { press, initialState, insertValue, formatExpr, preview, numToStr, evaluate } from './src/engine';

// The keypad must never mirror on an Arabic-language phone.
I18nManager.allowRTL(false);
I18nManager.forceRTL(false);

const HISTORY_KEY = 'swaper.history.v1';
const PREFS_KEY = 'swaper.prefs.v1';
const MAX_HISTORY = 300;
const THEME_MODES = ['system', 'light', 'dark'];
const THEME_ICON = { system: 'brightness-auto', light: 'light-mode', dark: 'dark-mode' };
const THEME_NAME = { system: 'تلقائي', light: 'فاتح', dark: 'داكن' };

function toast(msg) {
  if (Platform.OS === 'android') ToastAndroid.show(msg, ToastAndroid.SHORT);
}

const MAIN_KEYS = [
  [['AC', 'clear'], ['()', 'op'], ['%', 'op'], ['÷', 'op']],
  [['7'], ['8'], ['9'], ['×', 'op']],
  [['4'], ['5'], ['6'], ['−', 'op']],
  [['1'], ['2'], ['3'], ['+', 'op']],
  [['0'], ['.'], ['⌫', 'num', 'backspace'], ['=', 'eq']],
];

function Calculator() {
  const insets = useSafeAreaInsets();
  const { width, height } = useWindowDimensions();
  const system = useColorScheme();
  const [fontsLoaded] = useFonts({ GreatVibes_400Regular });

  const [themeMode, setThemeMode] = useState('system');
  const [deg, setDeg] = useState(true);
  const [inv, setInv] = useState(false);
  const [sciOpen, setSciOpen] = useState(false);
  const [calc, setCalc] = useState(initialState);
  const [history, setHistory] = useState([]);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [loaded, setLoaded] = useState(false);

  const theme = (themeMode === 'system' ? system : themeMode) === 'dark' ? dark : light;

  /* ---------- persistence ---------- */
  useEffect(() => {
    (async () => {
      try {
        const [h, p] = await Promise.all([AsyncStorage.getItem(HISTORY_KEY), AsyncStorage.getItem(PREFS_KEY)]);
        if (h) setHistory(JSON.parse(h));
        if (p) {
          const prefs = JSON.parse(p);
          if (THEME_MODES.includes(prefs.themeMode)) setThemeMode(prefs.themeMode);
          if (typeof prefs.deg === 'boolean') setDeg(prefs.deg);
          if (typeof prefs.sciOpen === 'boolean') setSciOpen(prefs.sciOpen);
        }
      } catch {}
      setLoaded(true);
    })();
  }, []);
  useEffect(() => {
    if (loaded) AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(history)).catch(() => {});
  }, [history, loaded]);
  useEffect(() => {
    if (loaded) AsyncStorage.setItem(PREFS_KEY, JSON.stringify({ themeMode, deg, sciOpen })).catch(() => {});
  }, [themeMode, deg, sciOpen, loaded]);

  /* ---------- animation values ---------- */
  const resultAnim = useRef(new Animated.Value(1)).current;
  const shake = useRef(new Animated.Value(0)).current;
  const panel = useRef(new Animated.Value(0)).current;
  const headerIn = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(headerIn, { toValue: 1, duration: 900, delay: 150, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
  }, []);
  useEffect(() => {
    Animated.spring(panel, { toValue: sciOpen ? 1 : 0, friction: 9, tension: 70, useNativeDriver: false }).start();
  }, [sciOpen]);

  /* ---------- sizing ---------- */
  const pad = 16;
  const gap = 10;
  const sciGap = 6;
  const sciH = 44;
  const sciW = (width - pad * 2 - sciGap * 4) / 5;
  const keyW = (width - pad * 2 - gap * 3) / 4;
  const panelOpenH = sciH * 3 + sciGap * 2;
  const reserved = insets.top + insets.bottom + 56 + height * 0.2 + panelOpenH + 16 + pad + 8;
  const keyH = Math.max(52, Math.min(keyW, (height - reserved - gap * 4) / 5));

  /* ---------- input ---------- */
  const handle = (key) => {
    const r = press(calc, key, deg);
    if (r.event === 'none') return;
    setCalc(r.state);
    if (r.event === 'result') {
      setHistory((h) => [r.entry, ...h].slice(0, MAX_HISTORY));
      resultAnim.setValue(0);
      Animated.spring(resultAnim, { toValue: 1, friction: 8, tension: 70, useNativeDriver: true }).start();
    } else if (r.event === 'error') {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error).catch(() => {});
      shake.setValue(0);
      Animated.sequence(
        [10, -10, 7, -7, 3, 0].map((x) => Animated.timing(shake, { toValue: x, duration: 45, useNativeDriver: true }))
      ).start();
    }
  };

  const copyResult = async () => {
    let text;
    try {
      text = numToStr(evaluate(calc.tokens, deg));
    } catch {
      text = formatExpr(calc.tokens);
    }
    if (!text) return;
    await Clipboard.setStringAsync(text);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
    toast('تم النسخ: ' + text);
  };

  const cycleTheme = () => {
    const next = THEME_MODES[(THEME_MODES.indexOf(themeMode) + 1) % THEME_MODES.length];
    setThemeMode(next);
    toast('المظهر: ' + THEME_NAME[next]);
  };

  /* ---------- display text ---------- */
  const main = formatExpr(calc.tokens) || '0';
  const upper = calc.justEvaluated && calc.lastExpr ? formatExpr(calc.lastExpr) + ' =' : '';
  const lower = calc.error || (calc.justEvaluated ? '' : preview(calc.tokens, deg));
  const len = main.length;
  const mainSize = len <= 8 ? 76 : len <= 11 ? 62 : len <= 15 ? 50 : len <= 21 ? 40 : 32;

  const sciRows = [
    [
      { label: '√' },
      { label: 'π' },
      { label: '^' },
      { label: '!' },
      { icon: 'expand-more', value: '__toggle' },
    ],
    [
      { label: deg ? 'DEG' : 'RAD', value: '__deg' },
      { label: inv ? 'sin⁻¹' : 'sin', value: inv ? 'sin⁻¹(' : 'sin(' },
      { label: inv ? 'cos⁻¹' : 'cos', value: inv ? 'cos⁻¹(' : 'cos(' },
      { label: inv ? 'tan⁻¹' : 'tan', value: inv ? 'tan⁻¹(' : 'tan(' },
      { label: 'INV', value: '__inv', active: inv },
    ],
    [
      { label: 'e' },
      { label: inv ? 'eˣ' : 'ln', value: inv ? 'eˣ' : 'ln(' },
      { label: inv ? '10ˣ' : 'log', value: inv ? '10ˣ' : 'log(' },
      { label: '1/x', value: '⁻¹' },
      { label: 'x²', value: '²' },
    ],
  ];

  const onSci = (v) => {
    if (v === '__toggle') return setSciOpen((o) => !o);
    if (v === '__deg') {
      setDeg((d) => !d);
      return toast(deg ? 'الزوايا: راديان' : 'الزوايا: درجات');
    }
    if (v === '__inv') return setInv((i) => !i);
    handle(v);
  };

  const chevronRotate = panel.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '180deg'] });

  return (
    <View style={[styles.root, { backgroundColor: theme.background }]}>
      <StatusBar style={theme.dark ? 'light' : 'dark'} />

      {/* top bar */}
      <View style={[styles.topBar, { marginTop: insets.top }]}>
        <Pressable
          onPress={() => setHistoryOpen(true)}
          android_ripple={{ color: theme.outlineVariant, borderless: true, radius: 22 }}
          style={styles.iconBtn}
          hitSlop={8}
        >
          <MaterialIcons name="history" size={24} color={theme.onSurfaceVariant} />
        </Pressable>

        <Animated.Text
          allowFontScaling={false}
          style={[
            styles.signature,
            {
              color: theme.primary,
              opacity: fontsLoaded ? headerIn.interpolate({ inputRange: [0, 1], outputRange: [0, 0.42] }) : 0,
              transform: [{ translateY: headerIn.interpolate({ inputRange: [0, 1], outputRange: [-8, 0] }) }],
            },
          ]}
        >
          For Swaper
        </Animated.Text>

        <Pressable
          onPress={cycleTheme}
          android_ripple={{ color: theme.outlineVariant, borderless: true, radius: 22 }}
          style={styles.iconBtn}
          hitSlop={8}
        >
          <MaterialIcons name={THEME_ICON[themeMode]} size={22} color={theme.onSurfaceVariant} />
        </Pressable>
      </View>

      {/* display */}
      <Pressable style={[styles.display, { paddingHorizontal: pad + 8 }]} onLongPress={copyResult} delayLongPress={350}>
        <Text style={[styles.mode, { color: theme.outline }]}>
          {deg ? 'DEG' : 'RAD'}
          {inv ? '  ·  INV' : ''}
        </Text>

        <Animated.Text
          numberOfLines={2}
          style={[
            styles.upper,
            {
              color: theme.onSurfaceVariant,
              opacity: resultAnim,
              transform: [{ translateY: resultAnim.interpolate({ inputRange: [0, 1], outputRange: [24, 0] }) }],
            },
          ]}
        >
          {upper}
        </Animated.Text>

        <Animated.Text
          numberOfLines={3}
          adjustsFontSizeToFit
          allowFontScaling={false}
          style={[
            styles.main,
            {
              color: theme.onSurface,
              fontSize: mainSize,
              lineHeight: mainSize * 1.15,
              transform: [
                { translateX: shake },
                { translateY: resultAnim.interpolate({ inputRange: [0, 1], outputRange: [36, 0] }) },
                { scale: resultAnim.interpolate({ inputRange: [0, 1], outputRange: [0.7, 1] }) },
              ],
            },
          ]}
        >
          {main}
        </Animated.Text>

        <Text
          numberOfLines={1}
          style={[styles.lower, { color: calc.error ? theme.error : theme.outline }, calc.error && styles.rtl]}
        >
          {lower}
        </Text>
      </Pressable>

      {/* scientific panel */}
      <View style={[styles.sciCard, { marginHorizontal: pad, backgroundColor: theme.surfaceContainer }]}>
        <Animated.View
          style={{
            height: panel.interpolate({ inputRange: [0, 1], outputRange: [sciH, panelOpenH] }),
            overflow: 'hidden',
          }}
        >
          {sciRows.map((row, r) => (
            <View key={r} style={[styles.row, { gap: sciGap, marginBottom: r < 2 ? sciGap : 0 }]}>
              {row.map((k, c) =>
                k.value === '__toggle' ? (
                  <Pressable
                    key="toggle"
                    onPress={() => onSci('__toggle')}
                    android_ripple={{ color: theme.outlineVariant, borderless: true, radius: sciH / 2 }}
                    style={{ width: sciW, height: sciH, alignItems: 'center', justifyContent: 'center' }}
                  >
                    <Animated.View style={{ transform: [{ rotate: chevronRotate }] }}>
                      <MaterialIcons name="expand-more" size={26} color={theme.onSurfaceVariant} />
                    </Animated.View>
                  </Pressable>
                ) : (
                  <Key
                    key={k.label + c}
                    label={k.label}
                    value={k.value ?? k.label}
                    variant="sci"
                    active={k.active}
                    w={sciW}
                    h={sciH}
                    fontSize={k.label.length > 3 ? 15 : 18}
                    theme={theme}
                    index={c}
                    onPress={onSci}
                  />
                )
              )}
            </View>
          ))}
        </Animated.View>
      </View>

      {/* main keypad */}
      <View style={{ paddingHorizontal: pad, paddingTop: 12, paddingBottom: insets.bottom + pad, gap }}>
        {MAIN_KEYS.map((row, r) => (
          <View key={r} style={[styles.row, { gap }]}>
            {row.map(([label, variant = 'num', icon], c) => (
              <Key
                key={label}
                label={label}
                icon={icon}
                variant={variant}
                w={keyW}
                h={keyH}
                theme={theme}
                index={5 + r * 4 + c}
                onPress={handle}
                onLongPress={label === '⌫' ? () => handle('AC') : undefined}
              />
            ))}
          </View>
        ))}
      </View>

      <HistorySheet
        open={historyOpen}
        onClose={() => setHistoryOpen(false)}
        history={history}
        theme={theme}
        topInset={insets.top}
        onClear={() => setHistory([])}
        onPick={(item) => {
          setCalc((s) => insertValue(s, item.value));
          setHistoryOpen(false);
        }}
        onEdit={(item) => {
          setCalc({ ...initialState, tokens: item.tokens || [] });
          setHistoryOpen(false);
        }}
      />
    </View>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <Calculator />
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, direction: 'ltr' },
  topBar: { height: 56, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 8 },
  iconBtn: { width: 48, height: 48, alignItems: 'center', justifyContent: 'center' },
  signature: { fontFamily: 'GreatVibes_400Regular', fontSize: 30, paddingHorizontal: 8 },
  display: { flex: 1, justifyContent: 'flex-end', paddingBottom: 12 },
  mode: { position: 'absolute', top: 4, left: 24, fontSize: 12, fontWeight: '600', letterSpacing: 1 },
  upper: { fontSize: 22, textAlign: 'right', minHeight: 28 },
  main: { textAlign: 'right', fontWeight: '300' },
  lower: { fontSize: 26, textAlign: 'right', minHeight: 34, fontWeight: '300' },
  rtl: { writingDirection: 'rtl', fontSize: 18 },
  sciCard: { borderRadius: 28, paddingHorizontal: 0, paddingVertical: 4 },
  row: { flexDirection: 'row', justifyContent: 'space-between' },
});
